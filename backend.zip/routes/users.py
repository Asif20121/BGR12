from flask import Blueprint, request, jsonify
from models import db, User
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from sqlalchemy.exc import IntegrityError
import datetime

users_bp = Blueprint('users', __name__)

# Register user
@users_bp.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    fullname = data.get('fullname')
    email = data.get('email')
    password = data.get('password')

    if not fullname or not email or not password:
        return jsonify({'message': 'Missing fields'}), 400

    hashed_password = User.hash_password(password)
    new_user = User(fullname=fullname, email=email, password=hashed_password)

    try:
        db.session.add(new_user)
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        return jsonify({'message': 'Email already registered'}), 400

    return jsonify({'message': 'User created successfully'}), 201

# Login
@users_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')

    user = User.query.filter_by(email=email).first()

    if user and User.check_password(user.password, password):
        access_token = create_access_token(identity={'email': user.email, 'role': user.role})
        return jsonify(access_token=access_token), 200

    return jsonify({'message': 'Invalid email or password'}), 401

# Get user profile (JWT required)
@users_bp.route('/user-profile', methods=['GET'])
@jwt_required()
def user_profile():
    current_user = get_jwt_identity()
    user = User.query.filter_by(email=current_user['email']).first()

    if user:
        user_details = {
            'id': user.id,
            'fullname': user.fullname,
            'email': user.email,
            'role': user.role
        }
        return jsonify({'user': user_details}), 200

    return jsonify({'message': 'User not found'}), 404
