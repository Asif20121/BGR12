from flask import Flask, request, jsonify, send_from_directory, send_file
from werkzeug.utils import secure_filename
from flask_cors import CORS
import os
import uuid
import zipfile
import cv2
from PIL import Image
import numpy as np
from rembg import remove, new_session
import torch
import shutil
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from sqlalchemy.exc import IntegrityError
import datetime
from datetime import timedelta
from functools import wraps
from models import db, bcrypt
from config import Config
from routes.users import users_bp
from routes.api import api_bp
from routes.billing import billing_bp
from routes.referral import referral_bp

app = Flask(__name__)
app.config.from_object(Config)
 #Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = 'supersecretkey' 
# app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(minutes=15)

db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
jwt = JWTManager(app)

# Register blueprints
app.register_blueprint(users_bp, url_prefix='/users')
app.register_blueprint(api_bp, url_prefix='/api')
app.register_blueprint(billing_bp, url_prefix='/billing')
app.register_blueprint(referral_bp, url_prefix='/referral')

# User Model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    fullname = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(50), default='general')

    def __repr__(self):
        return f'<User {self.fullname}>'

# Initialize the database
with app.app_context():
    db.create_all()
    
# Role-based access control decorator
def role_required(role):
    def decorator(fn):
        @wraps(fn)
        @jwt_required()
        def wrapper(*args, **kwargs):
            current_user = get_jwt_identity()
            if current_user['role'] != role:
                return jsonify({'message': f'Access restricted to {role} users'}), 403
            return fn(*args, **kwargs)
        return wrapper
    return decorator

# Register API
@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    fullname = data.get('fullname')
    email = data.get('email')
    password = data.get('password')

    if not fullname or not email or not password:
        return jsonify({'message': 'Missing fields'}), 400

    hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
    
    new_user = User(fullname=fullname, email=email, password=hashed_password)

    try:
        db.session.add(new_user)
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        return jsonify({'message': 'Email already registered'}), 400

    return jsonify({'message': 'User created successfully'}), 201

# Register Admin API
@app.route('/register-admin', methods=['POST'])
def register_admin():
    data = request.get_json()
    fullname = data.get('fullname')
    email = data.get('email')
    password = data.get('password')

    if not fullname or not email or not password:
        return jsonify({'message': 'Missing fields'}), 400

    hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
    
    new_admin = User(fullname=fullname, email=email, password=hashed_password, role='admin')

    try:
        db.session.add(new_admin)
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        return jsonify({'message': 'Email already registered'}), 400

    return jsonify({'message': 'Admin created successfully'}), 201


# Login API
@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')

    user = User.query.filter_by(email=email).first()

    if user and bcrypt.check_password_hash(user.password, password):
        access_token = create_access_token(identity={'email': user.email, 'role': user.role})
        return jsonify(access_token=access_token), 200

    return jsonify({'message': 'Invalid email or password'}), 401

# Dashboard API (paginated and searchable)
@app.route('/dashboard', methods=['GET'])
@jwt_required()
def dashboard():
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '', type=str)
    role = request.args.get('role', '', type=str)
    
    query = User.query.filter(
        (User.fullname.like(f'%{search}%')) | 
        (User.email.like(f'%{search}%'))
    )
    if role:  # Filter by role if specified
        query = query.filter_by(role=role)

    pagination = query.paginate(page=page, per_page=5)
    users = [{
        'id': user.id,
        'fullname': user.fullname,
        'email': user.email,
        'role': user.role
    } for user in pagination.items]

    return jsonify({
        'users': users,
        'total_pages': pagination.pages,
        'current_page': pagination.page
    }), 200
    
# Protected API - Admin Only
@app.route('/admin-profile', methods=['GET'])
@role_required('admin')  # Only admins can access this route
def admin_dashboard():
    current_user = get_jwt_identity()
    admin = User.query.filter_by(email=current_user['email']).first()

    if admin:
        admin_details = {
            'id': admin.id,
            'fullname': admin.fullname,
            'email': admin.email,
            'role': admin.role
        }
        return jsonify({'admin': admin_details}), 200

    return jsonify({'message': 'Admin not found'}), 404

# General User Dashboard - Display only the logged-in user's details
@app.route('/user-profile', methods=['GET'])
@role_required('general')  
def user_dashboard():
    current_user = get_jwt_identity()
    user = User.query.filter_by(email=current_user['email']).first()

    if user:
        user_details = {
            'id': user.id,
            'fullname': user.fullname,
            'email': user.email,
            'role': user.role
        }
        return jsonify({'user': user_details}), 200

    return jsonify({'message': 'User not found'}), 404


@app.route('/api/clear_temp_files', methods=['POST'])
def clear_temp_files():
    folders_to_clear = ['videos', 'uploads', 'processed', 'frames', 'background_frames']
    
    try:
        for folder in folders_to_clear:
            folder_path = os.path.join(app.root_path, folder)
            if os.path.exists(folder_path):
                for filename in os.listdir(folder_path):
                    file_path = os.path.join(folder_path, filename)
                    try:
                        if os.path.isfile(file_path) or os.path.islink(file_path):
                            os.unlink(file_path)
                        elif os.path.isdir(file_path):
                            shutil.rmtree(file_path)
                    except Exception as e:
                        print(f'Failed to delete {file_path}. Reason: {e}')

        return jsonify({"message": "All temporary files cleared successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

CORS(app)  # Allows cross-origin resource sharing (for React frontend)

# Configuration
app.config['UPLOAD_FOLDER'] = 'static/uploads/'
app.config['PROCESSED_FOLDER'] = 'static/processed/'
app.config['FRAMES_FOLDER'] = 'static/frames/'
app.config['PROCESSED_ZIP_FOLDER'] = 'static/processed_zips/'
app.config['VIDEOS_FOLDER'] = 'static/videos/'
app.config['BACKGROUND_FRAMES_FOLDER'] = 'static/background_frames/'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif', 'mp4', 'avi', 'mov'}
app.secret_key = 'super_secret_key'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB limit

# Create directories if they don't exist
for folder in [app.config['UPLOAD_FOLDER'], app.config['PROCESSED_FOLDER'], app.config['FRAMES_FOLDER'], app.config['PROCESSED_ZIP_FOLDER'], app.config['VIDEOS_FOLDER'], app.config['BACKGROUND_FRAMES_FOLDER']]:
    if not os.path.exists(folder):
        os.makedirs(folder)

processed_images = []
extracted_frames = []
background_frames = []


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']


def process_image_with_background(image_path, output_path, background_frames, background_color='transparent'):
    try:
        input_image = Image.open(image_path).convert("RGBA")
        
        if background_color == 'transparent':
            background_image = Image.new("RGBA", input_image.size, (255, 255, 255, 0))
        elif background_frames:
            background_frame_path = os.path.join(app.config['BACKGROUND_FRAMES_FOLDER'], np.random.choice(background_frames))
            background_image = Image.open(background_frame_path).convert("RGBA")
        else:
            background_image = Image.new("RGBA", input_image.size, background_color or (255, 255, 255, 255))
        
        background_image = background_image.resize(input_image.size)

        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        session = new_session("u2netp", device=device)
        output_image = remove(input_image, session=session)

        combined_image = Image.alpha_composite(background_image, output_image)
        combined_image.save(output_path, 'PNG')
    except Exception as e:
        print(f"Error processing image with background {image_path}: {e}")


def extract_frames_from_video(video_path, output_folder):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return []
    frame_count = 0
    extracted_frame_paths = []
    success, frame = cap.read()
    while success:
        frame_filename = f"frame_{uuid.uuid4()}.png"
        frame_path = os.path.join(output_folder, frame_filename)
        cv2.imwrite(frame_path, frame)
        extracted_frame_paths.append(frame_filename)
        frame_count += 1
        success, frame = cap.read()
    cap.release()
    return extracted_frame_paths


def remove_background_from_frames(frames, background_frames, background_color=None):
    processed_frames = []
    for frame in frames:
        frame_path = os.path.join(app.config['FRAMES_FOLDER'], frame)
        processed_frame_path = os.path.join(app.config['FRAMES_FOLDER'], f"processed_{frame}")
        try:
            process_image_with_background(frame_path, processed_frame_path, background_frames, background_color)
            processed_frames.append(f"processed_{frame}")
        except Exception as e:
            print(f"Error processing frame {frame_path}: {e}")
    return processed_frames


def create_video_from_frames(frames, output_video_path, frame_rate=30):
    if not frames:
        return

    frame_paths = [os.path.join(app.config['FRAMES_FOLDER'], frame) for frame in frames]

    first_frame = cv2.imread(frame_paths[0])
    if first_frame is None:
        return

    height, width, layers = first_frame.shape

    fourcc = cv2.VideoWriter_fourcc(*'avc1')  # H.264 codec
    video_writer = cv2.VideoWriter(output_video_path, fourcc, frame_rate, (width, height))

    for frame_path in frame_paths:
        frame = cv2.imread(frame_path)
        if frame is not None:
            video_writer.write(frame)

    video_writer.release()


@app.route('/process', methods=['POST'])
def process_files():
    global processed_images, extracted_frames
    processed_images.clear()  # Clear old results
    extracted_frames.clear()

    files = request.files.getlist('files[]')
    background_image = request.files.get('background_image')
    background_video = request.files.get('background_video')
    background_color = request.form.get('background_color', None)
    background_frames.clear()

    # Process background image (if provided)
    if background_image and allowed_file(background_image.filename):
        background_filename = secure_filename(background_image.filename)
        background_image_path = os.path.join(app.config['BACKGROUND_FRAMES_FOLDER'], background_filename)
        background_image.save(background_image_path)
        background_frames.append(background_filename)

    # Process background video (if provided)
    if background_video and allowed_file(background_video.filename):
        background_video_filename = secure_filename(background_video.filename)
        background_video_path = os.path.join(app.config['VIDEOS_FOLDER'], background_video_filename)
        background_video.save(background_video_path)

        # Extract frames from the background video
        extracted_background_frames = extract_frames_from_video(background_video_path, app.config['BACKGROUND_FRAMES_FOLDER'])
        background_frames.extend(extracted_background_frames)

    for file in files:
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            
            file_ext = filename.rsplit('.', 1)[1].lower()

            # Process image files
            if file_ext in {'png', 'jpg', 'jpeg', 'gif'}:
                processed_filename = f"processed_{filename.rsplit('.', 1)[0]}.png"
                processed_file_path = os.path.join(app.config['PROCESSED_FOLDER'], processed_filename)

                process_image_with_background(file_path, processed_file_path, background_frames, background_color)

                processed_images.append(processed_filename)

            # Process video files
            elif file_ext in {'mp4', 'avi', 'mov'}:
                extracted_frames.extend(extract_frames_from_video(file_path, app.config['FRAMES_FOLDER']))

                processed_frame_paths = remove_background_from_frames(extracted_frames, background_frames, background_color)

                processed_video_path = os.path.join(app.config['VIDEOS_FOLDER'], f"processed_{filename.rsplit('.', 1)[0]}.mp4")
                create_video_from_frames(processed_frame_paths, processed_video_path)

                return jsonify({
                    'processed_images': processed_images,
                    'processed_video': f"processed_{filename.rsplit('.', 1)[0]}.mp4"
                })

    return jsonify({
        'processed_images': processed_images,
        'extracted_frames': extracted_frames
    })


@app.route('/static/<path:path>')
def send_static(path):
    return send_from_directory('static', path, mimetype='video/mp4')


@app.route('/download/<filename>')
def download(filename):
    file_path = os.path.join(app.config['PROCESSED_ZIP_FOLDER'], filename)
    if not os.path.exists(file_path):
        return jsonify({'error': 'File not found'}), 404
    return send_from_directory(app.config['PROCESSED_ZIP_FOLDER'], filename, as_attachment=True)


@app.route('/download_all')
def download_all():
    zip_filename = f"processed_files_{uuid.uuid4()}.zip"
    zip_filepath = os.path.join(app.config['PROCESSED_ZIP_FOLDER'], zip_filename)

    with zipfile.ZipFile(zip_filepath, 'w') as zip_file:
        for processed_image in processed_images:
            image_path = os.path.join(app.config['PROCESSED_FOLDER'], processed_image)
            zip_file.write(image_path, os.path.basename(image_path))
        
        for frame in extracted_frames:
            frame_path = os.path.join(app.config['FRAMES_FOLDER'], frame)
            zip_file.write(frame_path, os.path.basename(frame_path))
    
    return send_from_directory(app.config['PROCESSED_ZIP_FOLDER'], zip_filename, as_attachment=True)


if __name__ == '__main__':
    app.run(debug=True)
