from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from main.api import user, auth,image
from main.database import engine, Base
import os

# Create the database tables
Base.metadata.create_all(bind=engine)

app = FastAPI()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Adjust as needed
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include the routers
app.include_router(auth.router)
app.include_router(user.router)
app.include_router(image.router)






# Configuration for Image API
app.config = {
    'UPLOAD_FOLDER': 'static/uploads/',
    'PROCESSED_FOLDER': 'static/processed/',
    'FRAMES_FOLDER': 'static/frames/',
    'PROCESSED_ZIP_FOLDER': 'static/processed_zips/',
    'VIDEOS_FOLDER': 'static/videos/',
    'BACKGROUND_FRAMES_FOLDER': 'static/background_frames/',
    'ALLOWED_EXTENSIONS': {'png', 'jpg', 'jpeg', 'gif', 'mp4', 'avi', 'mov'},
    'MAX_CONTENT_LENGTH': 16 * 1024 * 1024  # 16 MB limit
}

# Create directories if they don't exist
for folder in [
    app.config['UPLOAD_FOLDER'], 
    app.config['PROCESSED_FOLDER'], 
    app.config['FRAMES_FOLDER'], 
    app.config['PROCESSED_ZIP_FOLDER'], 
    app.config['VIDEOS_FOLDER'], 
    app.config['BACKGROUND_FRAMES_FOLDER']
]:
    os.makedirs(folder, exist_ok=True)

