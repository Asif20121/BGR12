from flask import Blueprint, jsonify

billing_bp = Blueprint('billing', __name__)

@billing_bp.route('/billing-info', methods=['GET'])
def billing_info():
    # Your billing info logic
    return jsonify({"message": "Billing info coming soon!"})
