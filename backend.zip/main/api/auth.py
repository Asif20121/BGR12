from datetime import datetime, timedelta
import random
from fastapi import APIRouter, Body, Depends, HTTPException
from sqlalchemy.orm import Session
from main.dependencies import create_access_token, get_current_user
from main.database import get_db
from main.models import CreditModel, UserModel
from main.schemas import PasswordUpdate, User, UserBase, UserCreate
from passlib.context import CryptContext
from fastapi import  Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
import uuid
from sqlalchemy.exc import IntegrityError


# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

from typing import List, Optional

router = APIRouter()



# User registration

@router.post("/register-refer/")
def register_user(fullname: str, email: str, password: str, referral_code: str = None, db: Session = Depends(get_db)):
    hashed_password = pwd_context.hash(password)
    
    # Check if user already exists
    existing_user = db.query(UserModel).filter(UserModel.email == email).first()
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered.")
    
    # Register the new user
    
    refer_key = str(uuid.uuid4())
    ev_code = str(random.randint(100000, 999999))  # Generate 6-digit random EV code
    ev_expire = datetime.utcnow() + timedelta(minutes=5)  # Set EV expire time to current time plus 5 minutes

    new_user = UserModel(
        fullname=fullname,
        email=email,
        password=hashed_password,
        refer_key=refer_key,
        ev_code=ev_code,
        ev_expire=ev_expire
    )
    db.add(new_user)
    
    # Handle referral if referral code is provided
    if referral_code:
        referrer = db.query(UserModel).filter(UserModel.refer_key == referral_code).first()
        if referrer:
            # Add bonus credits to the referrer
            referrer_credit = db.query(CreditModel).filter(CreditModel.user_id == referrer.id).first()
            if not referrer_credit:
                referrer_credit = CreditModel(user_id=referrer.id, total_credits=5.0)  # Bonus credit
            else:
                referrer_credit.total_credits += 5.0  # Add bonus credit
            db.add(referrer_credit)
    
    db.commit()
    db.refresh(new_user)
    
    return {"msg": "User registered successfully"}


# Admin registration
@router.post("/register-admin", response_model=UserBase)
async def register_admin(user: UserBase, db: Session = Depends(get_db)):
    user.password = pwd_context.hash(user.password)
    new_admin = UserModel(fullname=user.fullname, email=user.email, password=user.password, role='admin')

    db.add(new_admin)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Email already registered")

    return new_admin


@router.post("/register-user", response_model=UserBase)
async def register(user: UserCreate, db: Session = Depends(get_db)):
    user.password = pwd_context.hash(user.password)
    refer_key = str(uuid.uuid4())
    ev_code = str(random.randint(100000, 999999))  # Generate 6-digit random EV code
    ev_expire = datetime.utcnow() + timedelta(minutes=5)  # Set EV expire time to current time plus 5 minutes

    new_user = UserModel(
        fullname=user.fullname,
        email=user.email,
        password=user.password,
        refer_key=refer_key,
        ev_code=ev_code,
        ev_expire=ev_expire
    )
    db.add(new_user)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Email already registered")

    return new_user

@router.post("/generate-ev-code")
async def generate_ev_code(email: str, db: Session = Depends(get_db)):
    print(email)
    user = db.query(UserModel).filter(UserModel.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    ev_code = str(random.randint(100000, 999999))  # Generate 6-digit random EV code
    ev_expire = datetime.utcnow() + timedelta(minutes=5)  # Set EV expire time to current time plus 5 minutes

    user.ev_code = ev_code
    user.ev_expire = ev_expire
    db.commit()

    # Send the EV code to the user's email
    # ...

    return {"msg": "EV code generated and sent to your email"}

@router.post("/verify-ev-code")
async def verify_ev_code(email: str, ev_code: str, db: Session = Depends(get_db)):
    user = db.query(UserModel).filter(UserModel.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    if user.ev_code != ev_code:
        raise HTTPException(status_code=400, detail="Invalid EV code")

    if user.ev_expire < datetime.utcnow():
        raise HTTPException(status_code=400, detail="EV code has expired")
    
    user.ev_code = None
    user.ev_expire = None
    user.email_verified = True
    db.commit()

    # EV code is valid, you can proceed with the next steps
    return {"msg": "EV code is verified"}


@router.post("/forgot-password")
async def forgot_password(email: str, db: Session = Depends(get_db)):
    user = db.query(UserModel).filter(UserModel.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    fp_code = str(random.randint(100000, 999999))  # Generate 6-digit random FP code
    fp_expire = datetime.utcnow() + timedelta(minutes=5)  # Set FP expire time to current time plus 5 minutes

    user.fp_code = fp_code
    user.fp_expire = fp_expire
    db.commit()

    # Send the FP code to the user's email
    # ...

    return {"msg": "Forgot password code sent to your email"}

@router.post("/reset-password")
async def reset_password(email: str, fp_code: str, new_password: str, db: Session = Depends(get_db)):
    user = db.query(UserModel).filter(UserModel.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    if user.fp_code != fp_code:
        raise HTTPException(status_code=400, detail="Invalid FP code")

    if user.fp_expire < datetime.utcnow():
        raise HTTPException(status_code=400, detail="FP code has expired")
    user.fp_code = None
    user.fp_expire = None
    user.password = pwd_context.hash(new_password)
    db.commit()

    return {"msg": "Password reset successfully"}


# Login
@router.post("/login", response_model=dict)
async def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):

    user = db.query(UserModel).filter(UserModel.email == form_data.username).first()
    if not user or not pwd_context.verify(form_data.password, user.password):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    access_token = create_access_token(data={ "id": user.id,"sub": user.email,"role": user.role})
    return {"access_token": access_token, "token_type": "bearer"}

@router.post("/auth", response_model=dict)
async def login(login_data: dict = Body(...), db: Session = Depends(get_db)):
    email = login_data.get("email")
    password = login_data.get("password")

    user = db.query(UserModel).filter(UserModel.email == email).first()
    if not user or not pwd_context.verify(password, user.password):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    if not user.email_verified:
        await generate_ev_code(email, db)
        raise HTTPException(status_code=401, detail="Email not verified. Please verify your email address before logging in. We sent code to your email.")

    access_token = create_access_token(data={"id": user.id, "sub": user.email, "role": user.role})
    return {"access_token": access_token, "token_type": "bearer"}


# Define a function to verify a password
def verify_password(plain_password: str, hashed_password: str):
    return pwd_context.verify(plain_password, hashed_password)

@router.patch("/update-password")
async def update_password(password_update: PasswordUpdate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    # Verify the old password before updating the password
    if not verify_password(password_update.old_password, current_user.password):
        raise HTTPException(status_code=401, detail="Invalid old password")
    hashed_password = pwd_context.hash(password_update.new_password)
    current_user.password = hashed_password
    db_user = db.query(UserModel).filter(UserModel.id == current_user.id).first()
    db_user.password = hashed_password
    db.commit()
    return {"message": "Password updated successfully"}




