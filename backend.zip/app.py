from flask import Flask, request, jsonify, send_from_directory
from werkzeug.utils import secure_filename
from flask_cors import CORS
import os
import uuid
import zipfile
from PIL import Image
from rembg import remove
import shutil

app = Flask(__name__)

# Configuration
app.config['UPLOAD_FOLDER'] = 'static/uploads/'
app.config['PROCESSED_FOLDER'] = 'static/processed/'
app.config['FRAMES_FOLDER'] = 'static/frames/'
app.config['PROCESSED_ZIP_FOLDER'] = 'static/processed_zips/'
app.config['VIDEOS_FOLDER'] = 'static/videos/'
app.config['BACKGROUND_FRAMES_FOLDER'] = 'static/background_frames/'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif'}
app.secret_key = 'super_secret_key'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB limit

# Create directories if they don't exist
for folder in [
    app.config['UPLOAD_FOLDER'], app.config['PROCESSED_FOLDER'],
    app.config['FRAMES_FOLDER'], app.config['PROCESSED_ZIP_FOLDER'],
    app.config['VIDEOS_FOLDER'], app.config['BACKGROUND_FRAMES_FOLDER']
]:
    if not os.path.exists(folder):
        os.makedirs(folder)

CORS(app)  # Enables cross-origin resource sharing (for React frontend)

# Helper Functions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']


def process_image_with_background(image_path, output_path, background_color='transparent'):
    try:
        input_image = Image.open(image_path).convert("RGBA")
        
        if background_color == 'transparent':
            background_image = Image.new("RGBA", input_image.size, (255, 255, 255, 0))
        else:
            background_image = Image.new("RGBA", input_image.size, (255, 255, 255, 255))
        
        background_image = background_image.resize(input_image.size)

        # Remove background using rembg
        output_image = remove(input_image)

        combined_image = Image.alpha_composite(background_image, Image.fromarray(output_image))
        combined_image.save(output_path, 'PNG')
    except Exception as e:
        print(f"Error processing image {image_path}: {e}")


@app.route('/process', methods=['POST'])
def process_files():
    files = request.files.getlist('files[]')
    background_color = request.form.get('background_color', 'transparent')

    processed_images = []

    for file in files:
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            
            processed_filename = f"processed_{filename.rsplit('.', 1)[0]}.png"
            processed_file_path = os.path.join(app.config['PROCESSED_FOLDER'], processed_filename)

            process_image_with_background(file_path, processed_file_path, background_color)

            processed_images.append(processed_filename)

    return jsonify({'processed_images': processed_images})


@app.route('/static/<path:path>')
def send_static(path):
    return send_from_directory('static', path, mimetype='application/octet-stream')


@app.route('/download_all')
def download_all():
    zip_filename = f"processed_files_{uuid.uuid4()}.zip"
    zip_filepath = os.path.join(app.config['PROCESSED_ZIP_FOLDER'], zip_filename)

    with zipfile.ZipFile(zip_filepath, 'w') as zip_file:
        for processed_image in os.listdir(app.config['PROCESSED_FOLDER']):
            image_path = os.path.join(app.config['PROCESSED_FOLDER'], processed_image)
            zip_file.write(image_path, os.path.basename(image_path))
    
    return send_from_directory(app.config['PROCESSED_ZIP_FOLDER'], zip_filename, as_attachment=True)


@app.route('/clear_temp_files', methods=['POST'])
def clear_temp_files():
    folders_to_clear = [
        app.config['UPLOAD_FOLDER'], app.config['PROCESSED_FOLDER'],
        app.config['FRAMES_FOLDER'], app.config['BACKGROUND_FRAMES_FOLDER']
    ]

    try:
        for folder in folders_to_clear:
            for filename in os.listdir(folder):
                file_path = os.path.join(folder, filename)
                try:
                    if os.path.isfile(file_path) or os.path.islink(file_path):
                        os.unlink(file_path)
                    elif os.path.isdir(file_path):
                        shutil.rmtree(file_path)
                except Exception as e:
                    print(f"Failed to delete {file_path}. Reason: {e}")

        return jsonify({"message": "Temporary files cleared successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True)
