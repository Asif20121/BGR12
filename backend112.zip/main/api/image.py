
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, BackgroundTasks
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from main.dependencies import get_current_user
from main.database import get_db
import uuid
import os
import shutil
from werkzeug.utils import secure_filename
import zipfile
import time
import threading
import numpy as np
import cv2
from PIL import Image
from rembg import remove, new_session
import torch
from functools import wraps


router = APIRouter()



processed_images = []
extracted_frames = []
background_frames = []

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in router.config['ALLOWED_EXTENSIONS']

def clear_temp_files():
    folders_to_clear = ['videos', 'uploads', 'processed', 'frames', 'background_frames']
    
    for folder in folders_to_clear:
        folder_path = os.path.join(router.root_path, folder)
        if os.path.exists(folder_path):
            for filename in os.listdir(folder_path):
                file_path = os.path.join(folder_path, filename)
                try:
                    if os.path.isfile(file_path) or os.path.islink(file_path):
                        os.unlink(file_path)
                    elif os.path.isdir(file_path):
                        shutil.rmtree(file_path)
                except Exception as e:
                    print(f'Failed to delete {file_path}. Reason: {e}')

@router.post("/api/clear_temp_files")
async def api_clear_temp_files():
    try:
        clear_temp_files()
        return JSONResponse({"message": "All temporary files cleared successfully"}, status_code=200)
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)

def process_image_with_background(image_path, output_path, background_frames, background_color='transparent'):
    try:
        input_image = Image.open(image_path).convert("RGBA")
        
        if background_color == 'transparent':
            background_image = Image.new("RGBA", input_image.size, (0, 0, 0, 0))
        elif background_frames:
            background_frame_path = os.path.join(router.config['BACKGROUND_FRAMES_FOLDER'], np.random.choice(background_frames))
            background_image = Image.open(background_frame_path).convert("RGBA")
        else:
            background_image = Image.new("RGBA", input_image.size, (0, 0, 0, 0))
        
        background_image = background_image.resize(input_image.size)

        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        session = new_session("u2netp", device=device)
        output_image = remove(input_image, session=session)

        combined_image = Image.alpha_composite(background_image, output_image)
        combined_image.save(output_path, 'PNG')
    except Exception as e:
        print(f"Error processing image with background {image_path}: {e}")

def extract_frames_from_video(video_path, output_folder):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return []
    frame_count = 0
    extracted_frame_paths = []
    success, frame = cap.read()
    while success:
        frame_filename = f"frame_{uuid.uuid4()}.png"
        frame_path = os.path.join(output_folder, frame_filename)
        cv2.imwrite(frame_path, frame)
        extracted_frame_paths.append(frame_filename)
        frame_count += 1
        success, frame = cap.read()
    cap.release()
    return extracted_frame_paths

def remove_background_from_frames(frames, background_frames, background_color=None):
    processed_frames = []
    for frame in frames:
        frame_path = os.path.join(router.config['FRAMES_FOLDER'], frame)
        processed_frame_path = os.path.join(router.config['FRAMES_FOLDER'], f"processed_{frame}")
        try:
            process_image_with_background(frame_path, processed_frame_path, background_frames, background_color)
            processed_frames.append(f"processed_{frame}")
        except Exception as e:
            print(f"Error processing frame {frame_path}: {e}")
    return processed_frames

def create_video_from_frames(frames, output_video_path, frame_rate=30):
    if not frames:
        return

    frame_paths = [os.path.join(router.config['FRAMES_FOLDER'], frame) for frame in frames]

    first_frame = cv2.imread(frame_paths[0], cv2.IMREAD_UNCHANGED)
    if first_frame is None:
        return

    height, width = first_frame.shape[:2]

    fourcc = cv2.VideoWriter_fourcc(*'avc1')
    video_writer = cv2.VideoWriter(output_video_path, fourcc, frame_rate, (width, height))

    for frame_path in frame_paths:
        frame = cv2.imread(frame_path, cv2.IMREAD_UNCHANGED)
        if frame is not None:
            frame_bgr = cv2.cvtColor(frame, cv2.COLOR_RGBA2BGR)
            video_writer.write(frame_bgr)

    video_writer.release()

def delete_files_after_delay():
    time.sleep(300)  # Wait for 5 minutes
    clear_temp_files()

@router.post("/process")
async def process_files(
    files: list[UploadFile] = File(...),
    background_image: UploadFile = File(None),
    background_video: UploadFile = File(None),
    background_color: str = "transparent"
):
    global processed_images, extracted_frames
    processed_images.clear()
    extracted_frames.clear()

    # Process background image (if provided)
    if background_image and allowed_file(background_image.filename):
        background_filename = secure_filename(background_image.filename)
        background_image_path = os.path.join(router.config['BACKGROUND_FRAMES_FOLDER'], background_filename)
        with open(background_image_path, "wb") as image_file:
            image_file.write(await background_image.read())
        background_frames.append(background_filename)

    # Process background video (if provided)
    if background_video and allowed_file(background_video.filename):
        background_video_filename = secure_filename(background_video.filename)
        background_video_path = os.path.join(router.config['VIDEOS_FOLDER'], background_video_filename)
        with open(background_video_path, "wb") as video_file:
            video_file.write(await background_video.read())

        extracted_background_frames = extract_frames_from_video(background_video_path, router.config['BACKGROUND_FRAMES_FOLDER'])
        background_frames.extend(extracted_background_frames)

    for file in files:
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(router.config['UPLOAD_FOLDER'], filename)
            with open(file_path, "wb") as uploaded_file:
                uploaded_file.write(await file.read())
            
            file_ext = filename.rsplit('.', 1)[1].lower()

            if file_ext in {'png', 'jpg', 'jpeg', 'gif'}:
                processed_filename = f"processed_{filename.rsplit('.', 1)[0]}.png"
                processed_file_path = os.path.join(router.config['PROCESSED_FOLDER'], processed_filename)

                process_image_with_background(file_path, processed_file_path, background_frames, background_color)

                processed_images.append(processed_filename)

            elif file_ext in {'mp4', 'avi', 'mov'}:
                extracted_frames.extend(extract_frames_from_video(file_path, router.config['FRAMES_FOLDER']))
                processed_frame_paths = remove_background_from_frames(extracted_frames, background_frames, background_color)

                processed_video_path = os.path.join(router.config['VIDEOS_FOLDER'], f"processed_{filename.rsplit('.', 1)[0]}.mp4")
                create_video_from_frames(processed_frame_paths, processed_video_path)

                # Start the timer to delete files after 5 minutes
                threading.Thread(target=delete_files_after_delay).start()

                return JSONResponse({
                    'processed_images': processed_images,
                    'processed_video': f"processed_{filename.rsplit('.', 1)[0]}.mp4"
                })

    # Start the timer to delete files after 5 minutes
    threading.Thread(target=delete_files_after_delay).start()

    return JSONResponse({
        'processed_images': processed_images,
        'extracted_frames': extracted_frames
    })

# Serve static files
router.mount("/static", StaticFiles(directory="static"), name="static")

@router.get("/download/{filename}")
async def download(filename: str):
    file_path = os.path.join(router.config['PROCESSED_ZIP_FOLDER'], filename)
    if os.path.exists(file_path):
        return FileResponse(file_path, media_type='application/zip', filename=filename)
    raise HTTPException(status_code=404, detail="File not found")




