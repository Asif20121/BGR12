from typing import Optional
from pydantic import BaseModel
from fastapi_mail import FastMail, MessageSchema, ConnectionConfig


class UserBase(BaseModel):
    fullname: str
    email: str
    password: str

    class Config:
        from_attributes = True

class UserCreate(UserBase):
    password: str

class User(UserBase):
    id: int
    refer_key: str

    class Config:
        from_attributes = True

class PasswordUpdate(BaseModel):
    old_password: str
    new_password: str


