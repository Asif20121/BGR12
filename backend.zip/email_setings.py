
# from pydantic import BaseModel
# from fastapi_mail import FastMail, MessageSchema, ConnectionConfig



# # Email Configuration
# class EmailSettings(BaseModel):
#     MAIL_USERNAME: str = "your_email@example.com"
#     MAIL_PASSWORD: str = "your_email_password"
#     MAIL_FROM: str = "your_email@example.com"
#     MAIL_PORT: int = 587
#     MAIL_SERVER: str = "smtp.example.com"
#     MAIL_TLS: bool = True
#     MAIL_SSL: bool = False
#     MAIL_FROM_NAME: str = "Your App Name"

# email_settings = EmailSettings()

# conf = ConnectionConfig(
#     MAIL_USERNAME=email_settings.MAIL_USERNAME,
#     MAIL_PASSWORD=email_settings.MAIL_PASSWORD,
#     MAIL_FROM=email_settings.MAIL_FROM,
#     MAIL_PORT=email_settings.MAIL_PORT,
#     MAIL_SERVER=email_settings.MAIL_SERVER,
#     MAIL_TLS=email_settings.MAIL_TLS,
#     MAIL_SSL=email_settings.MAIL_SSL,
#     USE_CREDENTIALS=True,
#     VALIDATE_CERTS=True
# )




# # Utility function to create email message
# def create_referral_email(referred_email: str, refer_code: str, referrer_name: str):
#     email_body = f"""
#     Hi there,
    
#     You've been referred by {referrer_name} to join our service!
    
#     Use the following referral code during registration to get bonus credits:
    
#     Referral Code: {refer_code}
    
#     Join us today and enjoy the benefits!
    
#     Best Regards,
#     Your App Name Team
#     """

#     message = MessageSchema(
#         subject="You've Been Referred to Join Our Service!",
#         recipients=[referred_email],  # List of recipients
#         body=email_body,
#         subtype="plain"
#     )
#     return message
