from flask import Flask, request, jsonify
from models import User, db

@app.route('/transfer-credit', methods=['POST'])
def transfer_credit():
    # Ensure admin is authenticated
    token = request.headers.get('Authorization').split(" ")[1]
    admin = authenticate_admin_token(token)  # Add your admin authentication logic here

    if not admin:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401

    data = request.get_json()
    user_id = data.get('user_id')
    amount = data.get('amount')

    if not user_id or not amount or amount <= 0:
        return jsonify({'success': False, 'message': 'Invalid input'})

    # Find the user by ID
    user = User.query.filter_by(id=user_id).first()
    if not user:
        return jsonify({'success': False, 'message': 'User not found'}), 404

    try:
        # Update user's credits
        user.credits += amount
        db.session.commit()
        return jsonify({'success': True, 'message': 'Credits transferred successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': 'Failed to transfer credits'})
