from typing import Optional
import uuid
from fastapi import APIRouter, Depends, HTTPException
# from email_setings import create_referral_email,conf
from sqlalchemy.orm import Session
from main.dependencies import get_current_user, role_required
from main.database import get_db
from main.models import APIKeyModel, CreditModel, PlanModel, PurchaseHistoryModel, ReferralModel, UserModel
from main.schemas import User, UserCreate
from pydantic import EmailStr
from fastapi_mail import FastMail


router = APIRouter()


# Dashboard API
@router.get("/dashboard", response_model=dict)
@role_required("admin")
async def dashboard(page: int = 1, search: str = "", role: Optional[str] = None, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    query = db.query(UserModel).filter(
        (UserModel.fullname.like(f'%{search}%')) | 
        (UserModel.email.like(f'%{search}%'))
    )
    if role:
        query = query.filter(UserModel.role == role)

    pagination = query.offset((page - 1) * 5).limit(5).all()
    total_users = query.count()

    users = [{
        'id': user.id,
        'fullname': user.fullname,
        'email': user.email,
        'role': user.role
    } for user in pagination]

    return {
        'users': users,
        'total_pages': (total_users + 4) // 5,  # Calculate total pages
        'current_page': page
    }

# Admin profile API
@router.get("/admin-profile", response_model=User)
@role_required("admin")
async def admin_dashboard(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return current_user

# User profile API
@router.get("/user-profile", response_model=User)
async def user_dashboard(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return current_user



@router.delete("/profile-delete", response_model=User)
async def delete_current_user(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    db.delete(current_user)
    db.commit()
    return current_user

@router.delete("/admin/user-profile-delete", response_model=User)
@role_required("admin")
async def delete_user_by_admin(user_id: int, current_user: User = Depends(get_current_user),db: Session = Depends(get_db)):
    try:
        user = db.query(UserModel).filter(UserModel.id == user_id).first()
        if user is None:
            raise HTTPException(status_code=404, detail="User not found")

        db.delete(user)
        db.commit()
        return user
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error deleting user: {str(e)}")
    


    # Generate API key for user
@router.post("/generate-api-key/")
def generate_api_key(name: str, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    existing_api_keys = db.query(APIKeyModel).filter(APIKeyModel.user_id == current_user.id).count()
    if existing_api_keys >= 5:
        raise HTTPException(status_code=400, detail="You have already generated 5 API keys. Please delete one before generating a new one.")

    api_key = str(uuid.uuid4())  # Generate unique API key
    new_api_key = APIKeyModel(user_id=current_user.id, api_key=api_key, name=name)
    db.add(new_api_key)
    db.commit()
    db.refresh(new_api_key)
    return {"api_key": new_api_key.api_key, "request_limit": new_api_key.request_limit, "name": new_api_key.name}

@router.delete("/api-key/{name}")
def delete_api_key(name: str, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    api_key_to_delete = db.query(APIKeyModel).filter(APIKeyModel.user_id == current_user.id, APIKeyModel.name == name).first()
    if not api_key_to_delete:
        raise HTTPException(status_code=404, detail="API key not found or does not belong to you")

    db.delete(api_key_to_delete)
    db.commit()
    return {"message": "API key deleted successfully"}

@router.get("/api-keys/")
def get_api_keys(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    api_keys = db.query(APIKeyModel).filter(APIKeyModel.user_id == current_user.id).all()
    return [{"name": api_key.name,"api_key": api_key.api_key, "request_limit": api_key.request_limit} for api_key in api_keys]

@router.get("/admin/api-keys-all/")
@role_required("admin")
def get_api_keys(current_user: User = Depends(get_current_user),db: Session = Depends(get_db)):
    api_keys = db.query(APIKeyModel).all()
    return [{"api_key": api_key.api_key, "request_limit": api_key.request_limit, "user_id": api_key.user_id} for api_key in api_keys]

# Subscribe to a plan
@router.post("/subscribe/")
def subscribe(plan_id: int, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    plan = db.query(PlanModel).filter(PlanModel.id == plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")

    # Record the purchase history
    new_purchase = PurchaseHistoryModel(user_id=current_user.id, purchase_type="subscription", amount=plan.price)
    db.add(new_purchase)
    db.commit()
    db.refresh(new_purchase)

    return {"msg": f"User subscribed to {plan.name} plan for {plan.price}."}

@router.get("/subscribe/history/")
async def get_subscription_history(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    subscription_history = db.query(PurchaseHistoryModel).filter(PurchaseHistoryModel.user_id == current_user.id, PurchaseHistoryModel.purchase_type == "subscription").all()
    return [{"id": history.id,  "amount": history.amount, "created_at": history.created_at.isoformat()} for history in subscription_history]

@router.get("admin/subscribe/history-all/")
@role_required("admin")
async def get_all_subscription_history(current_user: User = Depends(get_current_user),db: Session = Depends(get_db)):
    subscription_history = db.query(PurchaseHistoryModel).filter(PurchaseHistoryModel.purchase_type == "subscription").all()
    return [{"id": history.id, "user_id": history.user_id,  "amount": history.amount, "created_at": history.created_at.isoformat()} for history in subscription_history]
# Top-up credits
@router.post("/top-up/")
def top_up(amount: float, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    user_credit = db.query(CreditModel).filter(CreditModel.user_id == current_user.id).first()
    if not user_credit:
        user_credit = CreditModel(user_id=current_user.id, total_credits=amount)
    else:
        user_credit.total_credits += amount
    db.add(user_credit)

    # Record the top-up in purchase history
    new_purchase = PurchaseHistoryModel(user_id=current_user.id, purchase_type="credit", amount=amount)
    db.add(new_purchase)
    db.commit()
    return {"msg": f"User credited with {amount} units."}


# Referral bonus credit
# Referral Endpoint
@router.post("/refer/")
async def refer_user(referred_email: EmailStr, current_user: UserModel = Depends(get_current_user), db: Session = Depends(get_db)):
    # Generate a referral code for the email
    refer_code = current_user.refer_key  # Using current user's refer key
    
    # Check if the referred email already exists in the system
    referred_user = db.query(UserModel).filter(UserModel.email == referred_email).first()
    if referred_user:
        raise HTTPException(status_code=400, detail="This email is already registered.")
    
    # Prepare and send the referral email
    # fm = FastMail(conf)
    # message = create_referral_email(referred_email, refer_code, current_user.fullname)
    
    # await fm.send_message(message)
    
    return {"msg": f"Referral email sent to {referred_email} with referral code: {refer_code}"}




@router.get("/purchase-history/")
async def get_purchase_history(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    purchases = db.query(PurchaseHistoryModel).filter(PurchaseHistoryModel.user_id == current_user.id).all()
    return [{"purchase_type": purchase.purchase_type, "amount": purchase.amount, "created_at": purchase.created_at.isoformat()} for purchase in purchases]
    
@router.get("/admin//purchase-history-all/")
@role_required("admin")
async def get_purchase_history(db: Session = Depends(get_db)):
    purchases = db.query(PurchaseHistoryModel).all()
    return [{"purchase_type": purchase.purchase_type, "amount": purchase.amount, "created_at": purchase.created_at.isoformat(), "user_id": purchase.user_id} for purchase in purchases]    


@router.post("/create-plan/")
@role_required("admin")
def create_plan(name: str, duration_in_days: int, price: float,current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    plan = PlanModel(name=name, duration_in_days=duration_in_days, price=price)
    db.add(plan)
    db.commit()
    db.refresh(plan)
    return {"msg": f"Plan '{name}' created successfully."}

@router.get("/credits")
async def get_credit_edit_history(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    credit_edit_history = db.query(CreditModel).filter(CreditModel.user_id == current_user.id).all()
    return [{"id": credit.id, "user_id": credit.user_id, "total_credits": credit.total_credits} for credit in credit_edit_history]

@router.get("/admin/credits/")
@role_required("admin")
async def get_all_credits(current_user: User = Depends(get_current_user),db: Session = Depends(get_db)):
    credits = db.query(CreditModel).all()
    return [{"id": credit.id, "user_id": credit.user_id, "total_credits": credit.total_credits} for credit in credits]