from flask import Blueprint, jsonify

referral_bp = Blueprint('referral', __name__)

@referral_bp.route('/referral-info', methods=['GET'])
def referral_info():
    # Your referral info logic
    return jsonify({"message": "Referral info coming soon!"})
