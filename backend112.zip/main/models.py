from sqlalchemy import Column, Integer, String,ForeignKey, Float, Boolean, DateTime
from sqlalchemy.orm import relationship
from main.database import Base
from datetime import datetime

class UserModel(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True, index=True)
    fullname = Column(String, index=True)
    email = Column(String, unique=True, index=True)
    password = Column(String)
    role = Column(String, default="general")
    email_verified = Column(Boolean, default=False)
    ev_code = Column(String) 
    ev_expire = Column(DateTime, default=None)
    fp_code = Column(String)
    fp_expire = Column(DateTime, default=None)
    free_credit = Column(Float, default=10.0)  # Free credit after registration
    refer_key = Column(String, unique=True, index=True)  # Unique refer key
    api_keys = relationship("APIKeyModel", back_populates="user")
    credits = relationship("CreditModel", back_populates="user")
    purchases = relationship("PurchaseHistoryModel", back_populates="user")

class PlanModel(Base):
    __tablename__ = 'plans'
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)
    duration_in_days = Column(Integer)  # E.g. 7 for weekly, 30 for monthly, 365 for yearly
    price = Column(Float)

class CreditModel(Base):
    __tablename__ = 'credits'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    user = relationship("UserModel", back_populates="credits")
    total_credits = Column(Float, default=0.0)

class APIKeyModel(Base):
    __tablename__ = 'api_keys'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    user = relationship("UserModel", back_populates="api_keys")
    name = Column(String)
    api_key = Column(String, unique=True, index=True)
    request_limit = Column(Integer, default=1000)  # Number of API requests allowed
    created_at = Column(DateTime, default=datetime.utcnow)

class ReferralModel(Base):
    __tablename__ = 'referrals'
    id = Column(Integer, primary_key=True, index=True)
    referrer_id = Column(Integer, ForeignKey('users.id'))
    referred_id = Column(Integer, ForeignKey('users.id'))
    bonus_credit = Column(Float, default=5.0)  # Bonus for referring
    referrer = relationship("UserModel", foreign_keys=[referrer_id])

class PurchaseHistoryModel(Base):
    __tablename__ = 'purchase_history'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    user = relationship("UserModel", back_populates="purchases")
    purchase_type = Column(String)  # Subscription or Credit purchase
    amount = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)